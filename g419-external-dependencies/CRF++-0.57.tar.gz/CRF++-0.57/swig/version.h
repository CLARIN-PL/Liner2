namespace CRFPP {
#define VERSION "0.57"
}
